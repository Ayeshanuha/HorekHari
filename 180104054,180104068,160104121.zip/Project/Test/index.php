 <?php 
 session_start();
	$db = new mysqli("localhost","root","","sign_up");
            if(isset($_POST['ok'])){
               $username = $_POST['name'];
		      $email = $_POST['email'];
			   $message = $_POST['message'];
			   
                $query = "INSERT INTO contact_us(user_name, email,message) 
VALUES ('$username' , '$email',' $message')";
		$run = mysqli_query($db, $query);

		if($run){
			$message = "Message sent  successfully.!";
			echo "<script type='text/javascript'>alert('$message');</script>";
		}else{
			echo "error".mysqli_error($db);
		}
            }
   
   ?>
   
   
   <!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link type="text/css"rel="stylesheet" href="css/style.css" />
	  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.1/css/all.min.css">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">

     <title>Send an Email</title>
  </head>
  <body>


	<style>
	
	body{
		background: rgb(95 169 177 / 10%);
  background-size: cover;
   display: flex;
   justify-content: center;
   align-items: center;
	}
	
.navbar {
	background : #000;
	padding : 1rem 3rem;
	z-index: 1000;
}

.navbar .navbar-brand {
	
	font-size : 1.4rem;
	font-weight : 700;
	
}

#navbarSupportedContent > ul > li:nth-child(n) > a:hover{
	color: #00BF85; 
	
}

#navbarSupportedContent > button {
	font-weight: 600;
	padding: 0.4rem 1.4rem;
	border-radius: 30px;

	
	
	
}

</style>
   
	<nav class="navbar navbar-expand-lg navbar-dark fixed-top  ">
	  <div class="container-fluid">
	    <a class="navbar-brand" href="#">হরেক হাড়ি</a>
	    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
	      <span class="navbar-toggler-icon"></span>
	    </button>
	    <div class="collapse navbar-collapse" id="navbarSupportedContent">
	      <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
		   <li class="nav-item">
	          <a class="nav-link font-weight-bold" href="http://localhost/Project/">Home</a>
	        </li>
	        <li class="nav-item">
	          <a class="nav-link" href="http://localhost/Project/aboutUs.html">About</a>
	        </li>
			<li class="nav-item">
	          <a class="nav-link" href="#discover">Discover</a>
	        </li>
			<li class="nav-item">
	          <a class="nav-link" href="#service">Service</a>
	        </li>
			<li class="nav-item">
	          <a class="nav-link" href="#product">product</a>
	        </li>
			<li class="nav-item">
	          <a class="nav-link" href="http://localhost/Project/Login & Registration /register.php">SignUp </a>
	        </li>
	        <li class="nav-item">
	          <a class="nav-link" href="http://localhost/Project/PROJECT_SD/index2.php">Team</a>
	        </li>
			<li class="nav-item">
	          <a class="nav-link" href="http://localhost/Project/Test/index.php">Contact</a>
	        </li>
	      </ul>
	         <a href="http://localhost/Project/Login & Registration/" >
	        <button class="btn btn-outline-success" type="submit" style="width: 90px; border-radius: 25px;">Log In
			</button>
			</a>
	    </div>
	  </div>
	</nav>
		<h4 class="sent-notification"></h4>
		
		
		
		
		
		<div class="contact-section">
		
		 <div class="contact-info" style="color: black;" >
       
        <div><i class="fas fa-envelope"></i>ayeshasiddikanuha@gmail.com</div>
        <div><i class="fas fa-phone"></i>+01234567890</div>
       
      </div>
	  	
		 <div class="contact-form">
        <h2 style="
		margin-
		color: black;
    font-size: 50px;
    margin-bottom: 44px;
    margin-top: 100px;
    font-weight: 400;
    font-family: ui-serif;
    font-style: italic;
		" >Get in touch! </h2>
		<form id="myForm" action="index.php" method="post" class="register-form">
			<input id="name" type="text"  name="name" placeholder="Enter Your Name">
			  
			<br>
			
			<input id="email" type="text"  name="email" placeholder="Enter Your Email">
			<br>
			
			<textarea id="body"  name="message"  rows="5" placeholder="Your Message"></textarea>
			
			
			<br>
			<button name="ok" style="width: 156px;
    border-radius: 20px;">Send message</button>
			

			
			 
		</form>
		
		</div>
		</div>
	

	<script src='http://code.jquery.com/jquery-3.3.1.min.js'></script>
	<script src="js/jquery-3.3.1.min.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/custom.js"></script>
	
  
  
  

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.min.js" integrity="sha384-j0CNLUeiqtyaRmlzUHCPZ+Gy5fQu0dQ6eZ/xAww941Ai1SxSY+0EQqNXNE6DZiVc" crossorigin="anonymous"></script>
    -->
  </body>
</html>
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   


<!--<!DOCTYPE html>
<html>
<head>
    <title>Send an Email</title>
	<link type="text/css"rel="stylesheet" href="css/style.css" />
	
	  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.1/css/all.min.css">
</head>
<body style=" 
background: rgb(95 169 177 / 10%);
  background-size: cover;
   display: flex;
   justify-content: center;
   align-items: center;">	
		<h4 class="sent-notification"></h4>
		
		
		
		<div class="contact-section">
		
		 <div class="contact-info" style="color: black;" >
       
        <div><i class="fas fa-envelope"></i>ayeshasiddikanuha@gmail.com</div>
        <div><i class="fas fa-phone"></i>+01234567890</div>
       
      </div>
	  	
		 <div class="contact-form">
        <h2 style="
		margin-
		color: black;
    font-size: 50px;
    margin-bottom: 44px;
    margin-top: 100px;
    font-weight: 400;
    font-family: ui-serif;
    font-style: italic;
		" >Get in touch! </h2>
		<form id="myForm" action="index.php" method="post" class="register-form">
			<input id="name" type="text"  name="name" placeholder="Enter Your Name">
			  
			<br>
			
			<input id="email" type="text"  name="email" placeholder="Enter Your Email">
			<br>
			
			<textarea id="body"  name="message"  rows="5" placeholder="Your Message"></textarea>
			
			
			<br>
			<button name="ok">Send message</button>
			

			
			 
		</form>
		
		</div>
		</div>
	

	<script src='http://code.jquery.com/jquery-3.3.1.min.js'></script>
	<script src="js/jquery-3.3.1.min.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/bootstarp.min.js"></script>
	<script src="js/custom.js"></script>
	
</body>
</html>-->
      