 <?php 
 session_start();
	$db = new mysqli("localhost","root","","sign_up");
            if(isset($_POST['ok'])){
               $username = $_POST['name'];
		      $email = $_POST['email'];
			   $message = $_POST['message'];
			   
                $query = "INSERT INTO contact_us(user_name, email,message) 
VALUES ('$username' , '$email',' $message')";
		$run = mysqli_query($db, $query);

		if($run){
			$message = "Message sent  successfully.!";
			echo "<script type='text/javascript'>alert('$message');</script>";
		}else{
			echo "error".mysqli_error($db);
		}
            }
            ?>


<!DOCTYPE html>
<html>
<head>
    <title>Send an Email</title>
	<link type="text/css"rel="stylesheet" href="css/style2.css" />
	
	  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.1/css/all.min.css">
</head>
<body style="height: 100vh; width: 100%;">	
		<h4 class="sent-notification"></h4>
		
		<div class="contact-section">
		
		 <div class="contact-info" style="color: pink;" >
       
        <div><i class="fas fa-envelope"></i>ayeshasiddikanuha@gmail.com</div>
        <div><i class="fas fa-phone"></i>+01234567890</div>
       
      </div>
	  	
		 <div class="contact-form">
        <h2 style="color: black;" >Contact Us </h2>
		<form id="myForm" action="index.php" method="post" class="register-form">
			<input id="name" type="text"  name="name" placeholder="Enter Your Name">
			  
			<br>
			
			<input id="email" type="text"  name="email" placeholder="Enter Your Email">
			<br>
			
			<textarea id="body"  name="message"  rows="5" placeholder="Your Message"></textarea>
			
			
			<br>
			<button name="ok">Send message</button>
			

			
			 
		</form>
		
		</div>
		</div>
	

	<script src='http://code.jquery.com/jquery-3.3.1.min.js'></script>
	<script src="js/jquery-3.3.1.min.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/bootstarp.min.js"></script>
	<script src="js/custom.js"></script>
	
</body>
</html>
      