<?php 

include 'config.php';

session_start();

error_reporting(0);

if (isset($_SESSION['username'])) {
    header("Location: welcome.php");
}

if (isset($_POST['submit'])) {
	$email = $_POST['email'];
	$password = $_POST['password'];

	$sql = "SELECT * FROM information WHERE email='$email' AND password='$password'";
	$result = mysqli_query($conn, $sql);
	if ($result->num_rows > 0) {
		$row = mysqli_fetch_assoc($result);
		$_SESSION['username'] = $row['username'];
		header("Location: welcome.php");
	} else {
		echo "<script>alert('Woops! Email or Password is Wrong.')</script>";
	}
}

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

	<link rel="stylesheet" type="text/css" href="style.css">

	<title>Login Form </title>
</head>
<body style=" background-image: linear-gradient(rgba(0,0,0,.5), rgba(0,0,0,.5)), url(papers.jpg);">
	<div class="container" style="background: #5c818c40;">
	<div class="one">
        <img src="user.png" style="box-sizing: border-box;width: 55px;height: 55px;border: 5px solid #0082e6;border-radius: 50%;background-color: white;margin-left: 145px;padding: 1px;/* transition: all 1s; */">
    </div>
		<form action="" method="POST" class="login-email">
			<p class="login-text" style="font-size: 29px;
    font-weight: 600;
    font-style: italic;
    font-family: ui-serif;
    color: #0a1961;">Login</p>
			<div class="input-group">
				<input type="email" style="border: 1px solid #8fbfbc;" placeholder="Email" name="email" value="<?php echo $email; ?>" required>
			</div>
			<div class="input-group">
				<input type="password"  style="border: 1px solid #8fbfbc;" placeholder="Password" name="password" value="<?php echo $_POST['password']; ?>" required>
			</div>
			<div class="input-group">
				<button name="submit" class="btn">Login</button>
			</div>
			<p class="login-register-text"  style="color: #111;
    font-weight: 400;
    font-family: ui-serif;
    font-size: 17px;">New Here ? <a href="register.php" style="color: #dad8ea;
			font-style: oblique;
    font-family: ui-monospace;">Register Here</a>.</p>
		</form>
	</div>
</body>
</html>