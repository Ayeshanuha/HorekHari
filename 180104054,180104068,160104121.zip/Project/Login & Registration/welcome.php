<?php 

include 'config.php';

session_start();

error_reporting(0);


if (!isset(($_SESSION['username']) )) {
    header("Location: index.php");
}

if($_GET['update'])
{
 $name=	$_GET['username'];
$email=	$_GET['email'];
$pass =	$_GET['password'];
	
	
     $query = "UPDATE information set email= '$email ' ,password='$pass'  where username = '$name'";
      $run = mysqli_query($conn,$query);
	  if($run)
	  {
		 echo '<script type="text/javascript"> alert("Updated Data is Saved")</script>';
	  }
	  else{
		   echo '<script type="text/javascript"> alert("Updated Data is Saved")</script>';
	  }

}

	
	/*
	  $currentUser = $_SESSION['username'];
	   $currentUseremail = $_SESSION['email'];
	    $currentUserpassword = $_SESSION['password'];
	//$username= $_POST['username'];
	$query = "Upadte information set email= ' $currentUseremail' where username ='$currentUser'";
	$query_run = mysqli_query($conn,$query);
	
	if($query_run)
	{
		echo '<script type="text/javascript"> alert("Data Updated")</script>';
	}
	else
	{
		echo '<script type="text/javascript"> alert("Data  not Updated")</script>';
	}
	
}*/
//../Login & Registration /userProfileUpdateProcess.php
?>

<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.1/css/all.min.css">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">

  


    <title>Userprofile</title>
  
    

</head>
<body style="background: #dee2e6;">
    <?php //echo "<h1>Welcome " . $_SESSION['username'] . "</h1>";
	?>
	
	
	<nav class="navbar navbar-expand-lg navbar-dark fixed-top bg-dark">
	  <div class="container-fluid">
	    <a class="navbar-brand" href="#">হরেক হাড়ি</a>
	    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
	      <span class="navbar-toggler-icon"></span>
	    </button>
	    <div class="collapse navbar-collapse" id="navbarSupportedContent">
	      <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
		  <li class="nav-item">
	          <a class="nav-link" href="http://localhost/Project/">Home</a>
	        </li>
	        <li class="nav-item">
	          <a class="nav-link" href="#about">About</a>
	        </li>
			<li class="nav-item">
	          <a class="nav-link" href="#discover">Discover</a>
	        </li>
			<li class="nav-item">
	          <a class="nav-link" href="#service">Service</a>
	        </li>
			<li class="nav-item">
	          <a class="nav-link" href="http://localhost/Project/Login & Registration /register.php">SignUp </a>
	        </li>
	        <li class="nav-item">
	          <a class="nav-link" href="teampage.html">Team</a>
	        </li>
			<li class="nav-item">
	          <a class="nav-link" href="http://localhost/Project/Test/index.php">Contact</a>
	        </li>
	      </ul>
		  <a href="http://localhost/Project/Login & Registration /logout.php">
	        <button class="btn btn-outline-success" type="submit">Log Out
			</button>
			</a>
	    </div>
	  </div>
	</nav>
	
	 <div class=" one" style="margin-top: 60px;">
            <h3 style="
			    text-align: center;
    margin-top: 10px;
    margin-bottom: 35px;
    color: #c18383;
    font-size: 45px;
    font-family: serif;
    font-style: italic;"
			>User Profile</h3>
       </div>
 <div class="top" style="margin-left: 30px; margin-right: 30px;">  
	
	 
	      <div class="row" style=
		  "margin-top: 20px;
    margin-left: 190px;
    margin-right: 30px;"
		  
		  >
            <div class="col-md-6 offset-3"> 
			
<div class="box">
<img src="user.png" style="margin-bottom: 10px;
box-sizing: border-box;
	width: 149px;
	height: 149px;
	border: 5px solid #0082e6;
	border-radius: 50%;
	background-color: white;
	padding: 3px;
	transition: all 1s;">
            <form action=""
			method="GET">			
             <?php
			   $currentUser = $_SESSION['username'];
                        $sql = "SELECT * FROM information WHERE username ='$currentUser'";
						$gotResuslts = mysqli_query($conn,$sql);
						  if($gotResuslts){
                            if(mysqli_num_rows($gotResuslts)>0){
                                while($row = mysqli_fetch_array($gotResuslts)){
                                    //print_r($row['user_name']);
									?>
									<div class="form-group">
									 <div class="form-group">
                                            <input type="file" style="width: 229px; background: rgb(0 0 0 / 8%); margin-bottom: 10px;" name="userImage" class="form-control">
                                        </div>
                                            <input type="text"  style="width: 350px;border-radius: 20px;margin-bottom: 10px;
    height: 50px;
    background: #dee2e6;
    border-bottom: 1px solid #1d2124;
    /* border: none; */
    font-family: ui-sans-serif;
    font-weight: 500;
    font-size: 25px;" name="username" class="form-control" value="<?php echo $row['username']; ?>" placeholder="Enter Your Name">
                                        </div>
                                        <div class="form-group">
                                            <input type="email" style="width: 350px;border-radius: 20px; margin-bottom: 10px;
    height: 50px;
    background: #dee2e6;
    border-bottom: 1px solid #1d2124;
    /* border: none; */
    font-family: ui-sans-serif;
    font-weight: 500;
    font-size: 25px;" name="email" class="form-control" value="<?php echo $row['email']; ?>" placeholder="Enter Your Email">
                                        </div>
										 <div class="form-group">
                                            <input type="password" style="width: 350px;border-radius: 20px;margin-bottom: 10px;
    height: 50px;
    background: #dee2e6;
    border-bottom: 1px solid #1d2124;
    /* border: none; */
    font-family: ui-sans-serif;
    font-weight: 500;
    font-size: 25px;" name="password" class="form-control" value="<?php echo $row['password']; ?>" placeholder="Enter Your password">
                                        </div>
                                       
                                       
                                        <div class="form-group">
                                            <input type="submit"  style="
											margin-top: 15px;
											color: black;
											margin-bottom: 10px;
											border-radius: 13px;
                                            background: #d7dbde;
                                            font-family: ui-sans-serif;" name="update"  class="btn btn-info" value="Save Changes">
                                        </div>
										<button  style="
										border: 1px;
                                         background-color: #bdd3e6;
                                        color: black;
                                              height: 30px;
                                             width: 70px;
                                         border-radius: 20px;
                                           margin: 0;
                                    transition: all 0.3s;
                                         font-family: ui-serif;"> 
										<a  style="text-decoration: none;" href="http://localhost/Project/PROJECT_SD/" >OK </a>
										</button>
	
	                                             
										
									<!--	 <a style="color: #382628;
    float: right;
    text-decoration: none;
    background-color: transparent;
	/* border: none;
    -webkit-text-decoration-skip: objects; */
    font-family: ui-serif;
    font-size: 20px;"   href="logout.php">Log out </a>-->
										
									<?php
								}
							}
						  }
			 ?>
                                        
                                   
                                

                    
                
                </form>
            </div>
			 </div>
            </div>
        </div>
		<script type="text/javascript">
		
		</script>
		   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
</body>
</html>