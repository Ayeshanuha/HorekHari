<?php

//starting session
session_start();

require_once('php/CreateDb2.php');
require_once('./php/component.php');

//creating instance
$database = new CreateDb();
?>



<!doctype html>
<html lang="en">
<head>

	<meta charset = "UTF-8">
	<meta name="viewport"
		content="width=device-width,user-scalable=no,initial-scale=1.0,maximum-scale=1.0,minimum-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">

	<link href="bootstrap.min.css" rel="stylesheet" >
	<link type="text/css" rel="stylesheet" href="style.css"/>
	<title> team</title>
</head>
<body>

<style>
img.img-fluid.card-img-top {
width: 50%;
}
body {
background: #70908e38;
}
	
	
	.navbar {
	background : #000;
	padding : 1rem 3rem;
	z-index: 1000;
}

.navbar .navbar-brand {
	
	font-size : 1.4rem;
	font-weight : 700;
	
}

#navbarSupportedContent > ul > li:nth-child(n) > a:hover{
	color: #00BF85; 
	
}

#navbarSupportedContent > button {
	font-weight: 600;
	padding: 0.4rem 1.4rem;
	border-radius: 30px;

	
	
	
}

</style>



	<?php require_once("php/header2.php");?>
	<div>

<h4 style="text-align: center;
    font-size: 41px;
    font-style: italic;
    font-family: ui-serif;
    margin-top: 110px;
    margin-bottom: 50px;
    color: #5e4c7d;"> Our Team

</h4>
	</div>
	<div class="container">
	

		<div class="shera row text-center py=5">
			<?php
				$result = $database->getData();
                while ($row = mysqli_fetch_assoc($result)){
                    component2($row['name'], $row['Roll'],  $row['email'], $row['product_image']);
                }
			?>
		</div>
	</div>

	<footer>



	</footer>






<script src="bootstrap.bundle.min.js" ></script>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html>