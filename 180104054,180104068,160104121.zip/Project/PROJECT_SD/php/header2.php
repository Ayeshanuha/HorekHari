<header>
			<nav class="navbar navbar-expand-lg navbar-dark fixed-top">
	  <div class="container-fluid">
	    <a class="navbar-brand" href="">হরেক হাড়ি</a>
	    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
	      <span class="navbar-toggler-icon"></span>
	    </button>
	    <div class="collapse navbar-collapse" id="navbarSupportedContent">
	      <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
		   <li class="nav-item">
	          <a class="nav-link" href="http://localhost/Project/">Home</a>
	        </li>
	        <li class="nav-item">
	          <a class="nav-link" href="http://localhost/Project/aboutUs.html">About</a>
	        </li>
			<li class="nav-item">
	          <a class="nav-link" href="#discover">Discover</a>
	        </li>
			<li class="nav-item">
	          <a class="nav-link" href="#service">Service</a>
	        </li>
			<li class="nav-item">
	          <a class="nav-link" href="#product">product</a>
	        </li>
			<li class="nav-item">
	          <a class="nav-link" href="http://localhost/Project/Login & Registration /register.php">SignUp </a>
	        </li>
	        <li class="nav-item">
	          <a class="nav-link" href="http://localhost/Project/PROJECT_SD/index2.php">Team</a>
	        </li>
			<li class="nav-item">
	          <a class="nav-link" href="http://localhost/Project/Test/index.php">Contact</a>
	        </li>
	      </ul>
		  <a href="http://localhost/Project/Login & Registration /">
	        <button class="btn btn-outline-success" type="submit" style="width: 90px; border-radius: 25px;">Log In
			</button>
			</a>
			 
	    </div>
	  </div>
	</nav>
	
		

		</header>